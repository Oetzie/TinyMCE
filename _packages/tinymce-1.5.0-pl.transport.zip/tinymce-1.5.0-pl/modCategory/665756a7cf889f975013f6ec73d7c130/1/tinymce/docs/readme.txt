----------------------
TinyMCE
----------------------
Version: 1.5.0
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------