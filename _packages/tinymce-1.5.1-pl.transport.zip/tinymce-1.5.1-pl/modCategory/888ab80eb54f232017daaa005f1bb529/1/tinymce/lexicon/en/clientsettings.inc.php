<?php

/**
 * TinyMCE
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$_lang['clientsettings.tinymce.name']                           = 'TinyMCE editor';

$_lang['clientsettings.tinymce.label_config']                   = 'TinyMCE config';
$_lang['clientsettings.tinymce.label_config_desc']              = 'The TinyMCE config for the TinyMCE editor.';
