<?php

/**
 * TinyMCE
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/tinymceconfig.class.php';

class TinyMCEConfig_mysql extends TinyMCEConfig
{
}
