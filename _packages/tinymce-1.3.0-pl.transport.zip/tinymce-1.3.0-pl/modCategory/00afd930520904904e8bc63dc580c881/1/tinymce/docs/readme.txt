----------------------
TinyMCE
----------------------
Version: 1.3.0
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------